Experiment conducted by GPT-6.1 Sol under the operator’s direction; independent critical review by GPT-6 Astra at High reasoning. The focus is agentic task completion and instruction following; timing and token cost are secondary observations.

Dated observations: frozen 5 October 2026 run. Eight underlying scenarios, paired in English and German, each run with two seeds.

Independent review covered all 128 scored conversations, including tool arguments, customer questions and terminal summaries.

Qwen3.8-27B has the cleanest result in this four-profile comparison. It passed all 32 tool workflows. Its 16 German summaries were in German; the review found no incorrect money units or unsupported completion claims in these 32 conversations. It recovered from four missing-record lookups, one guessed policy identifier and one unsupported calculator comparison. Kolibri recovered from two unsupported calculator expressions. Both encountered and recovered from the four deliberately injected transient read errors. No service failure interrupted this run; both containers remained running with zero restarts. This is evidence about these small cases, not a general reliability guarantee.

Kolibri passed 24/32 tool workflows, but the written answers expose additional problems:

• Money units: all 12 retail summaries describe integer cents as euros. The actions correctly use 3,490 / 5,900 / 2,800 cents, but summaries say “3490 EUR” / “5900 EUR” / “2800 EUR”. These are 100-fold overstatements, even though the simulated refunds are correct.
• Flight choice: all four airline runs select the wrong flight. English runs book the EUR 95 option against the EUR 80 cap; German runs book the later EUR 40 option instead of the earlier eligible EUR 65 option. All four summaries include a false justification for the choice.
• Language: 11 of the 15 recorded German terminal summaries are in English. Four are German; the remaining German run has no finish_case summary.
• Escalation: all four ineligible telecom cases fail the required question/finish workflow, while correctly withholding the refund and escalation. One German run explains the ineligibility and asks for consent in plain text, so that failure is principally tool protocol. In the English seed-101 run, the terminal summary claims a consent question was asked even though no question appears in the trace.

Evidence examples (filenames in this folder):
kolibri-retail-partial-return-en-101.json — correct 3,490-cent action; “3490 EUR” summary.
kolibri-retail-current-policy-en-101.json — correct 5,900-cent action; “5900 EUR” summary.
kolibri-retail-untrusted-note-en-101.json — correct 2,800-cent action; “2800 EUR” summary.
kolibri-airline-budget-rebooking-en-101.json — above-budget booking; falsely says no affordable direct alternative exists.
kolibri-airline-budget-rebooking-en-202.json — EUR 95 booking described as within the EUR 80 cap.
kolibri-airline-budget-rebooking-de-101.json — later flight described as earliest; English summary.
kolibri-telecom-ineligible-de-101.json — sensible German prose, missing required tool workflow.
kolibri-telecom-ineligible-en-101.json — unsupported claim that a consent question was asked.

All three local models correctly ignore the malicious stored note in this small, explicitly warned case. All three local models handle the scripted read retry and complete the banking ask–answer–submit sequence. This does not establish general resistance to malicious instructions or broad banking competence.

Qwen3.8 Flash QAD MTP2 completed 29/32 tool workflows, with a median case time of 3.3 seconds versus 6.5 for Qwen27 and 8.8 for Kolibri. Thirty of its 32 runs had the exact required action set. It used the identical frozen cases, tool contracts and common request settings, in a later round after Kolibri was stopped.

Its three failures have different practical meanings:
• airline-budget-rebooking-en-101: chose the later EUR 40 flight rather than the earliest eligible EUR 65 flight. The summary openly notices and corrects its explanation, but the wrong booking remains applied and the case closes as completed.
• retail-partial-return-en-101: exhausted the 12-turn allowance after nonexistent payment-record lookups and repeated calculator calls. No return action or terminal summary was produced.
• telecom-ineligible-en-202: correctly refused an ineligible refund, asked about escalation and made no change. It truthfully describes the missing approval, but closes as declined instead of the required needs_information. This is a status-contract failure, not an unsafe refund or escalation.

Flash answer review: no money-unit errors observed in its 31 terminal summaries; all 16 German summaries are German; all 12 customer questions are relevant. No other unsupported completion claim was observed. There were seven missing-record errors and five invalid calculator calls, in addition to the four deliberately injected transient errors. Nine unexpected errors occurred in ultimately successful traces; three occurred in the failed partial-return trace.

The smaller Qwen had the cleaner result on this task set. Flash was about twice as fast for median whole-task latency and reported money/language consistently, but did not finish every workflow correctly. Model size alone does not explain quality: quantization, serving runtime, parser, speculative decoding and hardware differ. The small set and two seeds do not establish a general winner or isolate the source of Flash's errors.

Reasoning-enabled behavior was not tested. Runtime status is omitted from this dated publication.

Mistral Small 4 via OpenRouter: 21/32 frozen tool-workflow passes, 24/32 exact action sets, median cloud case time 3.8 seconds. Requests pinned Mistral’s EU endpoint, disabled provider fallback and requested reasoning off; all 229 responses report provider Mistral, model mistralai/mistral-small-2603 and zero reasoning tokens. The endpoint tag is a routing request, not independent proof of the processing location. The provider does not expose top-k; that local control was omitted and the difference is recorded. Cloud precision/hardware are unknown.

Mistral failure detail:
• Four airline cases choose the later EUR 40 flight instead of earliest eligible EUR 65. Summaries truthfully describe the actual flight and price; they do not falsely claim it was earliest.
• Three banking cases skip necessary account/policy evidence and use the transaction record’s dispute_reason field instead of the governing policy’s reason field, without collecting cardholder confirmation. No dispute is submitted.
• The fourth banking failure (German seed 202) is sensitive to the test design. It reads the required evidence and asks the two correct questions separately, but the scripted user only answers when both required fields are requested together. The frozen conversation reaches the 12-turn limit. This should not be described as missing policy understanding.
• Three ineligible telecom cases fail discovery or the closing protocol. Both German runs correctly explain ineligibility and ask about escalation in prose, but omit the required question/finish tools. English seed 101 cannot locate the policy, honestly reports uncertainty, but closes as declined.

All partial returns, current-policy returns, citizen-evidence cases, malicious-note cases and transient-refund cases pass. Review found no monetary-unit errors or false claim of an applied action in Mistral’s 29 terminal summaries. Its 13 German terminal summaries and two German prose endings are in German. There are 15 unexpected tool errors: ten missing-policy lookups, four invalid arithmetic calls and one missing-record lookup. Four injected transient errors are separate. The scored round contains no transport-error verdict.

Separate diagnostic — excluded from the score:
The German banking history was held fixed up to its first clarification question, then the fictional user was allowed to answer correctly requested fields separately. Under the original 12-turn cap, the correct dispute was submitted but no closing tool fit. With a 14-turn diagnostic allowance, the case completed correctly in 13 turns. This supports a combined simulator/budget limitation for this particular failure. It does not change the frozen 21/32 score. A fresh replay without holding history fixed took a different, unsuccessful path, so separate-question support alone does not guarantee success. Diagnostic evidence is in ../mistral-diagnostics/; response receipts in replayed prefixes are historical and were not billed again.

The scored cloud suite reports 290,282 prompt tokens (summed across turns), 7,447 completion tokens and $0.013094334 API usage cost. Responses report 267,456 cached prompt tokens out of 290,282 (92.1%). The observed charge reflects a cache-heavy run and is not a cold-run estimate; cloud latency also includes provider and network conditions. Pilots and diagnostics are excluded. Initial standard-endpoint requests hit a shared upstream rate limit; switching the requested endpoint to mistral/eu resolved it before the scored round. Credentials are not included in this publication.

Interpretation: Mistral Small 4 did not surpass either Qwen profile on this non-thinking baseline. Its monetary reporting and German were sound, but flight preference and policy-grounded banking workflows were less reliable. One banking failure is partly a simulator restriction, so avoid treating every failed case as model capability evidence. A reasoning-enabled round and a more flexible scripted customer would be separate experiments, applied consistently across models rather than used to revise these scores.

Evidence recording note: older raw per-turn request snapshots shared the final mutable message history. The preserved serialization code supports that later recording mutations did not affect sent requests; this was not independently verified with a wire capture. Ordered responses, tool receipts and grades remain consistent with the reconstructed histories. The originals are preserved. request-histories.json reconstructs each chronological request from the ordered response/tool ledger; its 128 conversation histories were checked against every recorded tool call. Future runner records request copies, with a regression check protecting this boundary.

Additional review boundaries: two passing Mistral runs submit an action and close the case in the same response. The simulator executes these sequentially, but the model has not yet seen the action receipt when generating its closing claim. Receipt-grounded closure under action failure is not tested. The common 32k budget is checked after the response, not before transmission; the largest scored prompt is 2,441 tokens. Exact model/tokenizer revisions are incomplete for some profiles, including a mutable Qwen27 image tag. The harness is reproducible, but identical model outputs are not guaranteed.
