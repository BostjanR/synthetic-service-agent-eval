# Frozen reviewed experiment — 5 October 2026

Eight scenario structures, each in English and German, with seeds 101 and 202: 32 conversations per deployed profile. The two languages are paired variants, not independent scenario families. No real accounts, bookings, refunds, emails or services were affected.

All requests use temperature 0.2, top-p 0.95, reasoning requested off, max 1,024 output tokens per turn, 12 turns and a 240-second case budget. Local profiles use top-k 128. Mistral does not expose it; its omitted controls and provider routing request are recorded in the manifest. One sequential worker per model; local first-round models ran concurrently on different hosts. Flash was evaluated later. Median case times include model calls, simulated tools and, for Mistral, network/provider delay. They are not decode-speed comparisons.

Banking customer replies require both missing fields together. The separate-question diagnosis is excluded from scores. Eight scenario families and two seeds are too few to establish general model superiority, production readiness, or a reliable population-level error rate. All cases explicitly describe the tool contract; the malicious-note case warns that retrieved notes are untrusted. Search returns a small set of fixture records, not a realistic retrieval workload.

Original per-turn request snapshots contain a shared-list recording defect. Derived chronological request histories are published separately and checked against ordered responses/tool receipts; they are not wire captures. Sanitization changes endpoint/private operational metadata only and preserves tool results, prompts, actions, grading decisions and timing. Check provenance.json for before/after hashes.

See deployment-profiles.json for available runtime information. Exact upstream revisions are incomplete; this prevents exact replication of every deployed profile. Natural-language findings below are a dated review of this frozen run, not conclusions that should be reused for future runs.


Experiment conducted by **GPT-6.1 Sol**, with an independent critical review by **GPT-6 Astra at High**, under **BostjanR’s direction**. The review checked the harness and preserved evidence; it is not human-verified certification.
