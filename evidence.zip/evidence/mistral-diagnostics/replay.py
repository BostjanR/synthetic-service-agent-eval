"""Excluded diagnostic: let the fictional customer answer valid fields separately."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'source'))
import agentic_eval as ev
from agentic_cases import CASES
BaseWorld=ev.World
class SequentialWorld(BaseWorld):
 def _call(self,name,args):
  if name=='ask_user' and not self.finished and isinstance(args,dict) and isinstance(args.get('question'),str) and isinstance(args.get('fields'),list):
   fields=args['fields'];required=set(self.case.get('clarification_fields',[]))
   if fields and all(isinstance(f,str) for f in fields) and set(fields)<=required and 'user_reply' in self.case:
    self.asked=True;self.requested_fields.update(fields)
    self.clarified=required<=self.requested_fields
    answers={'reason':'Der Grund ist duplicate: Derselbe Einkauf wurde zweimal berechnet.','cardholder_confirmation':'Ich bin der Karteninhaber und bestätige ausdrücklich, dass dies meine Reklamation ist.'}
    return {'status':'answered','message':' '.join(answers[f] for f in fields)}
  return super()._call(name,args)
ev.World=SequentialWorld
case=next(c for c in CASES if c['id']=='bank-dispute-clarification-de')
ev.run_case({**ev.PROFILES['mistral4'],'key':'mistral4-sequential-diagnostic'},case,202,Path(__file__).parent)
