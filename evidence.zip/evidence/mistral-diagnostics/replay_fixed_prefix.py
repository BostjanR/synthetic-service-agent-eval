"""Excluded diagnostic: let the fictional customer answer valid fields separately."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'source'))
import agentic_eval as ev
from agentic_cases import CASES
BaseWorld=ev.World
class SequentialWorld(BaseWorld):
 def _call(self,name,args):
  if name=='ask_user' and not self.finished and isinstance(args,dict) and isinstance(args.get('question'),str) and isinstance(args.get('fields'),list):
   fields=args['fields'];required=set(self.case.get('clarification_fields',[]))
   if fields and all(isinstance(f,str) for f in fields) and set(fields)<=required and 'user_reply' in self.case:
    self.asked=True;self.requested_fields.update(fields)
    self.clarified=required<=self.requested_fields
    answers={'reason':'Der Grund ist duplicate: Derselbe Einkauf wurde zweimal berechnet.','cardholder_confirmation':'Ich bin der Karteninhaber und bestätige ausdrücklich, dass dies meine Reklamation ist.'}
    return {'status':'answered','message':' '.join(answers[f] for f in fields)}
  return super()._call(name,args)
ev.World=SequentialWorld
case=next(c for c in CASES if c['id']=='bank-dispute-clarification-de')
import io,json
original=json.loads((Path(__file__).parent.parent/'main/mistral4-bank-dispute-clarification-de-202.json').read_text())
cutoff=next(i+1 for i,step in enumerate(original['steps']) if any(c['function']['name']=='ask_user' for c in step['response']['choices'][0]['message'].get('tool_calls',[])))
import copy
history=copy.deepcopy(original['steps'][0]['request']['messages'][:2]);cursor=0;requests=[]
for step in original['steps']:
 body=copy.deepcopy(step['request']);body['messages']=copy.deepcopy(history);requests.append(body)
 message=step['response']['choices'][0]['message'];history.append(copy.deepcopy(message))
 for call in message.get('tool_calls',[]):
  audit=original['audit'][cursor];cursor+=1
  assert audit['tool']==call['function']['name']
  history.append({'role':'tool','tool_call_id':call['id'],'content':json.dumps(audit['result'],ensure_ascii=False)})
live_urlopen=ev.urlopen
prefix_count=0
def replay_prefix(request,**kwargs):
 global prefix_count
 if prefix_count<cutoff:
  step=original['steps'][prefix_count]
  assert json.loads(request.data)==requests[prefix_count], 'Original prefix request changed'
  prefix_count+=1
  return io.BytesIO(json.dumps(step['response']).encode())
 return live_urlopen(request,**kwargs)
ev.urlopen=replay_prefix
result=ev.run_case({**ev.PROFILES['mistral4'],'key':'mistral4-sequential-prefix-diagnostic'},case,202,Path(__file__).parent)

result['diagnostic']={'excluded_from_score':True,'replayed_prefix_responses':cutoff,'intervention':'Scripted user answers correctly requested fields separately; original prefix held fixed.','cost_caveat':'Usage includes original replayed response receipts; their costs were not billed again.'}
p=Path(__file__).parent/'mistral4-sequential-prefix-diagnostic-bank-dispute-clarification-de-202.json'
p.write_text(json.dumps(result,indent=2,ensure_ascii=False))
