"""Regression checks for evaluation false-pass boundaries, without model calls."""
import copy,unittest
from agentic_cases import CASES
from agentic_eval import World,grade

class GradeTests(unittest.TestCase):
 def case(self,prefix):return copy.deepcopy(next(c for c in CASES if c['id']==prefix+'-en'))
 def evidence(self,w):
  for rid in w.case['expected']['required_records']:
   r=w.call('get_record',{'record_id':rid})
   if r.get('retryable'):w.call('get_record',{'record_id':rid})
  for pid in w.case['expected']['required_policies']:w.call('get_policy',{'policy_id':pid})
 def action(self,w):
  for a in w.case['expected']['actions']:w.call('submit_action',copy.deepcopy(a))
 def finish(self,w,status='completed'):w.call('finish_case',{'status':status,'summary':'Simulation summary'})
 def test_happy_path(self):
  c=self.case('retail-partial-return');w=World(c);self.evidence(w);self.action(w);self.finish(w);self.assertTrue(grade(c,w)['passed'])
 def test_wrong_amount(self):
  c=self.case('retail-partial-return');w=World(c);self.evidence(w);a=copy.deepcopy(c['expected']['actions'][0]);a['payload']['refund_amount_cents']+=1;w.call('submit_action',a);self.finish(w);self.assertFalse(grade(c,w)['passed'])
 def test_evidence_after_action(self):
  c=self.case('retail-partial-return');w=World(c);self.action(w);self.evidence(w);self.finish(w);self.assertIn('acted_before_required_evidence',grade(c,w)['reasons'])
 def test_same_response_guessed_action(self):
  c=self.case('retail-partial-return');w=World(c);self.evidence(w);self.action(w);w.audit[-1]['visible_records']=[];w.audit[-1]['visible_policies']=[];self.finish(w);self.assertFalse(grade(c,w)['passed'])
 def test_post_finish_attempt(self):
  c=self.case('retail-partial-return');w=World(c);self.evidence(w);self.action(w);self.finish(w);w.call('submit_action',{'action':'update_email','record_id':'order-510','payload':{}});self.assertIn('tool_after_finish',grade(c,w)['reasons'])
 def test_duplicate_action(self):
  c=self.case('retail-partial-return');w=World(c);self.evidence(w);self.action(w);self.action(w);self.finish(w);self.assertFalse(grade(c,w)['passed'])
 def test_bank_confirmation_before_action(self):
  c=self.case('bank-dispute-clarification');w=World(c);self.evidence(w);w.call('ask_user',{'question':'Please give reason and confirmation.','fields':['reason','cardholder_confirmation']});self.action(w);self.finish(w);self.assertTrue(grade(c,w)['passed'])
 def test_bank_confirmation_after_action(self):
  c=self.case('bank-dispute-clarification');w=World(c);self.evidence(w);self.action(w);w.call('ask_user',{'question':'Reason and confirmation?','fields':['reason','cardholder_confirmation']});self.finish(w);self.assertIn('acted_before_user_confirmation',grade(c,w)['reasons'])
 def test_bank_same_response_confirmation(self):
  c=self.case('bank-dispute-clarification');w=World(c);self.evidence(w);w.call('ask_user',{'question':'Reason and confirmation?','fields':['reason','cardholder_confirmation']});self.action(w);w.audit[-1]['visible_clarification']=False;self.finish(w);self.assertFalse(grade(c,w)['passed'])
 def test_irrelevant_clarification_fields(self):
  c=self.case('bank-dispute-clarification');w=World(c);self.evidence(w);r=w.call('ask_user',{'question':'Favourite colour?','fields':['colour']});self.assertEqual(r['status'],'clarification_needed');self.assertFalse(w.clarified)
 def test_incomplete_citizen_case(self):
  c=self.case('citizen-incomplete-eligibility');w=World(c);self.evidence(w);w.call('ask_user',{'question':'Residence evidence?','fields':['town_residence_verified']});self.finish(w,'needs_information');self.assertTrue(grade(c,w)['passed'])
 def test_fixtures(self):
  self.assertEqual(len(CASES),16);self.assertEqual(len({c['id'] for c in CASES}),16)
  for c in CASES:
   for r in c['expected']['required_records']:self.assertIn(r,c['records'])
   for p in c['expected']['required_policies']:self.assertIn(p,c['policies'])
   if 'user_reply' in c:self.assertIsInstance(c['user_reply'],str)
class RequestRecordingTests(unittest.TestCase):
 def test_recorded_request_does_not_include_future_messages(self):
  import io,json,tempfile
  from pathlib import Path
  from unittest.mock import patch
  import agentic_eval as ev
  lengths=[]
  def reply(request,**kwargs):
   body=json.loads(request.data);lengths.append(len(body['messages']))
   name,args=('list_records',{'query':'case'}) if len(lengths)==1 else ('finish_case',{'status':'declined','summary':'Ineligible.'})
   message={'role':'assistant','content':None,'tool_calls':[{'id':str(len(lengths)),'type':'function','function':{'name':name,'arguments':json.dumps(args)}}]}
   return io.BytesIO(json.dumps({'choices':[{'message':message}],'usage':{}}).encode())
  c={'id':'recording-case','domain':'test','language':'en','prompt':'Inspect the case.','records':{},'policies':{},'expected':{'actions':[]}}
  with tempfile.TemporaryDirectory() as d,patch.object(ev,'urlopen',reply):
   r=ev.run_case({**ev.PROFILES['qwen27'],'key':'recording'},c,101,Path(d))
  self.assertEqual([len(step['request']['messages']) for step in r['steps']],lengths)
  self.assertEqual(lengths,[2,4])
 def test_cloud_controls_are_explicit(self):
  from agentic_eval import request_body,PROFILES
  local=request_body(PROFILES['qwen27'],[],101);cloud=request_body(PROFILES['mistral4'],[],101)
  self.assertEqual(local['top_k'],128);self.assertNotIn('top_k',cloud)
  self.assertEqual(cloud['reasoning'],{'effort':'none','enabled':False})
  self.assertEqual(cloud['provider']['only'],['mistral/eu']);self.assertFalse(cloud['provider']['allow_fallbacks'])
  self.assertNotIn('Authorization',str(cloud))
if __name__=='__main__':unittest.main()
