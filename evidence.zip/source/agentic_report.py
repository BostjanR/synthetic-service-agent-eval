#!/usr/bin/env python3
"""Generate a portable report for any completed run. Qualitative review is separate."""
import argparse,html,json,statistics
from pathlib import Path

def main():
 p=argparse.ArgumentParser();p.add_argument('run',type=Path);a=p.parse_args();run=a.run
 rows=json.loads((run/'summary.json').read_text());manifest=json.loads((run/'manifest.json').read_text())
 assert len(rows)==len(manifest['profiles'])*len(manifest['case_ids'])*len(manifest['seeds'])
 groups={k:[r for r in rows if r['profile']['key']==k] for k in manifest['profiles']}
 assert all(groups.values())
 notes=(run/'report-notes.md').read_text() if (run/'report-notes.md').exists() else 'New run. Deployment information and qualitative review are pending. Mechanical passes do not establish complete instruction following.'
 review=(run/'qualitative-review.md').read_text() if (run/'qualitative-review.md').exists() else 'Qualitative review pending. Inspect tool calls, natural-language claims, money units and language before drawing conclusions.'
 headers=['Deployed profile','Tool-workflow passes','Median case time','Exact action sets']
 table=[]
 for key,rs in groups.items():
  table.append([rs[0]['profile']['label'],f"{sum(r['verdict']['passed'] for r in rs)}/{len(rs)}",f"{statistics.median(r['seconds'] for r in rs):.1f}s",f"{sum(r['verdict']['actual_actions']==r['verdict']['expected_actions'] for r in rs)}/{len(rs)}"])
 md=['# Synthetic service-agent comparison','',notes,'','| '+' | '.join(headers)+' |','|---|---:|---:|---:|']
 md+=['| '+' | '.join(row)+' |' for row in table]
 md+=['','## Reviewed answers','',review,'','## Individual evidence','']
 links=[]
 for r in rows:
  name=f"{r['profile']['key']}-{r['case_id']}-{r['seed']}.json";assert (run/name).is_file()
  label=f"{r['profile']['key']} · {r['case_id']} · {r['seed']}: {'PASS' if r['verdict']['passed'] else 'FAIL'}"
  md.append(f'- [{label}]({name})');links.append(f'<li><a href="{name}">{html.escape(label)}</a></li>')
 extra=['manifest.json','summary.json']+[n for n in ['request-histories.json','deployment-profiles.json'] if (run/n).exists()]
 md+=['','## Supporting files','',' · '.join(f'[{n}]({n})' for n in extra),'']
 (run/'report.md').write_text('\n'.join(md))
 def row_html(row,tag):return '<tr>'+''.join(f'<{tag}>{html.escape(str(x))}</{tag}>' for x in row)+'</tr>'
 cards=''.join(f'<article><h2>{html.escape(row[0])}</h2><strong>{row[1]}</strong><p>workflow passes</p><p>{row[2]} median case · {row[3]} exact action sets</p></article>' for row in table)
 body='''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Synthetic service-agent comparison</title><style>body{margin:0;background:#edf3f3;color:#18313b;font:16px/1.65 system-ui,sans-serif}main{max-width:1100px;margin:auto;padding:40px 24px}h1{font-size:42px;line-height:1.15}.cards{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:20px}article{background:white;padding:24px;border:1px solid #d7e3e5;border-radius:18px}article h2{font-size:20px;margin:0}strong{font-size:48px;color:#096c59}pre{white-space:pre-wrap;font:inherit;background:white;padding:24px;border-radius:12px}table{border-collapse:collapse;width:100%;background:white}td,th{padding:12px;text-align:left;border-bottom:1px solid #d7e3e5}.scroll{overflow:auto}a{color:#075f75}li{margin:8px 0}footer{margin-top:32px;color:#526c76}@media(max-width:650px){.cards{grid-template-columns:1fr}h1{font-size:32px}}</style><main><h1>Can they finish the service task?</h1><p>Fictional customers, policies and tools. Mechanical workflow scores and a separate review of the actual answers.</p>'''
 body+=f'<div class="cards">{cards}</div><h2>Method and limits</h2><pre>{html.escape(notes)}</pre><div class="scroll"><table>{row_html(headers,"th")}{"".join(row_html(r,"td") for r in table)}</table></div><h2>Reviewed answers</h2><pre>{html.escape(review)}</pre><h2>Individual evidence</h2><ul>{"".join(links)}</ul><h2>Supporting files</h2>'
 body+=' · '.join(f'<a href="{n}">{n}</a>' for n in extra)
 body+='<footer>Eight paired scenario families and two seeds do not establish general model superiority. All effects are simulated.</footer></main></html>'
 (run/'report.html').write_text(body)
 print(json.dumps({k:sum(r['verdict']['passed'] for r in rs) for k,rs in groups.items()}))
if __name__=='__main__':main()
