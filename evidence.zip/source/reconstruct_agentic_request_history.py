#!/usr/bin/env python3
"""Derive chronological requests from preserved response and tool receipts."""
import argparse,copy,json
from pathlib import Path

def main():
 p=argparse.ArgumentParser();p.add_argument('run',type=Path);a=p.parse_args();traces={}
 rows=json.loads((a.run/'summary.json').read_text())
 for row in rows:
  name=f"{row['profile']['key']}-{row['case_id']}-{row['seed']}.json"
  r=json.loads((a.run/name).read_text());history=copy.deepcopy(r['steps'][0]['request']['messages'][:2]) if r['steps'] else [];cursor=0;requests=[]
  for step in r['steps']:
   body=copy.deepcopy(step['request']);body['messages']=copy.deepcopy(history);requests.append(body)
   message=step['response']['choices'][0]['message'];history.append(copy.deepcopy(message))
   for call in message.get('tool_calls',[]):
    entry=r['audit'][cursor];cursor+=1;assert entry['tool']==call['function']['name']
    assert entry['arguments']==json.loads(call['function']['arguments'])
    history.append({'role':'tool','tool_call_id':call['id'],'content':json.dumps(entry['result'],ensure_ascii=False)})
  assert cursor==len(r['audit']);traces[name]=requests
 (a.run/'request-histories.json').write_text(json.dumps({'note':'Derived per-turn requests reconstructed from immutable ordered responses and tool audit. Older raw request snapshots shared a final mutable message list; original files and scores are preserved. Future runner saves copies.','traces':traces},ensure_ascii=False,indent=2))
 print(f'{len(traces)} chronological request histories checked against tool names and arguments; original traces unchanged.')
if __name__=='__main__':main()
