#!/usr/bin/env python3
"""Combine separately scheduled model rounds only when their contracts match."""
import argparse,copy,json,shutil
from pathlib import Path

def main():
 p=argparse.ArgumentParser();p.add_argument('runs',nargs='+',type=Path);p.add_argument('--out',type=Path,required=True);a=p.parse_args()
 manifests=[json.loads((r/'manifest.json').read_text()) for r in a.runs]
 shared=['system_prompt','tools','cases_sha256','seeds','case_ids','settings']
 for m in manifests[1:]:
  for key in shared:assert m[key]==manifests[0][key],f'Round mismatch: {key}'
 merged=copy.deepcopy(manifests[0]);merged['profiles']=[];merged['rounds']=[];merged['transport_overrides']={};rows=[];copies=[];seen=set()
 for run,m in zip(a.runs,manifests):
  assert not set(m['profiles']) & set(merged['profiles']), 'Duplicate profile round'
  merged['transport_overrides'].update(m.get('transport_overrides',{}))
  merged['profiles'].extend(m['profiles']);merged['rounds'].append({'source_directory':str(run),'profiles':m['profiles']})
  rs=json.loads((run/'summary.json').read_text())
  wanted={(profile,cid,seed) for profile in m['profiles'] for cid in m['case_ids'] for seed in m['seeds']}
  actual={(r['profile']['key'],r['case_id'],r['seed']) for r in rs};assert len(actual)==len(rs) and actual==wanted
  for r in rs:
   name=f"{r['profile']['key']}-{r['case_id']}-{r['seed']}.json";path=run/name
   raw=json.loads(path.read_text());assert raw['verdict']==r['verdict'] and raw['usage']==r['usage']
   assert name not in seen;seen.add(name);copies.append((path,name))
  rows.extend(rs)
 a.out.mkdir(parents=True,exist_ok=True)
 for path,name in copies:
  if path.resolve()!=(a.out/name).resolve():shutil.copy2(path,a.out/name)
 (a.out/'manifest.json').write_text(json.dumps(merged,indent=2))
 (a.out/'summary.json').write_text(json.dumps(rows,indent=2,ensure_ascii=False))
 print(f'Combined {len(rows)} distinct traces across {len(merged["profiles"])} models; common case/tool/settings contracts match; transport overrides retained.')
if __name__=='__main__':main()
