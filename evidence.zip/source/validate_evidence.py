"""Offline audit: fixtures, tool replay, stored grades and derived request histories."""
import copy,hashlib,json,sys
from pathlib import Path
from agentic_eval import World,grade
from agentic_cases import CASES

def main():
 run=Path(sys.argv[1]);rows=json.loads((run/'summary.json').read_text());manifest=json.loads((run/'manifest.json').read_text())
 assert hashlib.sha256(json.dumps(CASES,sort_keys=True).encode()).hexdigest()==manifest['cases_sha256']
 cases={c['id']:c for c in CASES};sidecar=json.loads((run/'request-histories.json').read_text())['traces'];counts={};calls=0
 for row in rows:
  name=f"{row['profile']['key']}-{row['case_id']}-{row['seed']}.json";r=json.loads((run/name).read_text())
  assert {k:v for k,v in r.items() if k not in {'steps','case','audit'}}==row
  assert r['case']==cases[r['case_id']]
  world=World(copy.deepcopy(r['case']))
  for entry in r['audit']:
   assert world.call(entry['tool'],copy.deepcopy(entry['arguments']))==entry['result']
   for k in ['visible_records','visible_policies','visible_clarification']:
    if k in entry:world.audit[-1][k]=entry[k]
   calls+=1
  actual=grade(r['case'],world);stored=r['verdict']
  for k in ['expected_status','actual_status','expected_actions','actual_actions']:assert actual[k]==stored[k]
  assert actual['reasons']==stored['reasons'][:len(actual['reasons'])]
  # Remaining reasons belong to bounded transport/termination, not the business grader.
  extra=stored['reasons'][len(actual['reasons']):]
  assert all(x in ['step_budget','stopped_without_finish_case','case_wall_budget','common_context_budget'] or x.startswith(('HTTPError:','TimeoutError:','URLError:')) for x in extra),extra
  assert (actual['passed'] and not extra)==stored['passed']
  history=copy.deepcopy(r['steps'][0]['request']['messages'][:2]);cursor=0
  for step,body in zip(r['steps'],sidecar[name]):
   expected=copy.deepcopy(step['request']);expected['messages']=copy.deepcopy(history);assert expected==body
   message=step['response']['choices'][0]['message'];history.append(copy.deepcopy(message))
   for call in message.get('tool_calls',[]):
    entry=r['audit'][cursor];cursor+=1
    assert entry['tool']==call['function']['name'];assert entry['arguments']==json.loads(call['function']['arguments'])
    history.append({'role':'tool','tool_call_id':call['id'],'content':json.dumps(entry['result'],ensure_ascii=False)})
  assert cursor==len(r['audit']);assert len(sidecar[name])==len(r['steps'])
  counts.setdefault(row['profile']['key'],0);counts[row['profile']['key']]+=int(stored['passed'])
 assert len(rows)==128 and calls==971
 print(json.dumps({'conversations':len(rows),'tool_calls':calls,'scores':counts,'derived_histories_checked':len(sidecar)},indent=2))
if __name__=='__main__':main()
